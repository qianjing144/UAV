#include "ch32v20x.h"
#include "UART.h"

void UART1_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};
    USART_InitTypeDef USART_InitStructure = {0};

    // 1. ʹ��ʱ��
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_USART1 | RCC_APB2Periph_AFIO, ENABLE);
    GPIO_PinRemapConfig(GPIO_Remap_USART1, ENABLE);
    // 2. ����PB6Ϊ�����������(UART1_TX)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;  // �����������
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    // 3. ����UART1����
    USART_InitStructure.USART_BaudRate = 115200;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Tx;  // ��ʹ�ܷ���ģʽ
    
    USART_Init(USART1, &USART_InitStructure);

    // 4. ʹ��UART1
    USART_Cmd(USART1, ENABLE);
}

void UART1_SendByte(uint8_t byte)
{
    USART_SendData(USART1, byte);
    while(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
}

void UART1_SendString(char *str)
{
    while(*str)
    {
        UART1_SendByte(*str++);
    }
}

// int main(void)
// {
//     // ϵͳʱ�ӳ�ʼ��
//     SystemCoreClockUpdate();
    
//     // UART1��ʼ��
//     UART1_Init();
    
//     // ���Ͳ����ַ���
//     UART1_SendString("UART1 Output Only Test\r\n");
    
//     while(1)
//     {
//         // ��ѭ��
//     }
// }
