#pragma once
#include "ch32v20x.h"

// const uint8_t LED1 = 1;
// const uint8_t LED2 = 2;
// const uint8_t LED3 = 3;
// const uint8_t LED4 = 4;

typedef enum {
    LED1 = 1,
    LED2 = 2,
    LED3 = 3,
    LED4 = 4,
} LED_e;

typedef enum {
    GPIO_Pin_LED1=GPIO_Pin_15,
    GPIO_PIN_LED2=GPIO_Pin_14,
    GPIO_PIN_LED3=GPIO_Pin_13,
    GPIO_PIN_LED4=GPIO_Pin_12,
} LED_GPIO_e;

void LED_Init (void);
void LED_On (LED_e LEDx);
void LED_Off (LED_e LEDx);
void LED_DisplayBinary(uint8_t num);