#pragma once
#include "ch32v20x.h"

void MCU_Restart(void);