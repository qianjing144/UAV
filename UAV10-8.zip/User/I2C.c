#include "I2C.h"
#include "LED.h"

void I2C_Init_All(void) {
    GPIO_InitTypeDef GPIO_InitStructure;
    I2C_InitTypeDef I2C_InitStructure;
    
    // ʹ��GPIO��I2Cʱ��
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1, ENABLE);
    
    // ����I2C1��SDA��SCL����Ϊ���ÿ�©���ģʽ
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    
    // ����I2C1������ӳ��
    GPIO_PinRemapConfig(GPIO_Remap_I2C1, ENABLE);
    
    // ����I2C1
    I2C_InitStructure.I2C_Mode = I2C_Mode_I2C;
    I2C_InitStructure.I2C_DutyCycle = I2C_DutyCycle_2;
    I2C_InitStructure.I2C_OwnAddress1 = 0x00;
    I2C_InitStructure.I2C_Ack = I2C_Ack_Enable;
    I2C_InitStructure.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;
    I2C_InitStructure.I2C_ClockSpeed = 100000; // 100kHz
    I2C_Init(I2C1, &I2C_InitStructure);
    
    // ʹ��I2C1
    I2C_Cmd(I2C1, ENABLE);
}

uint8_t I2C_WriteMulti(uint8_t devAddr, uint8_t regAddr, uint8_t *data, uint16_t len) {
    uint32_t timeout = 10000;
    
    
    while (I2C_GetFlagStatus(I2C1, I2C_FLAG_BUSY))
    ; // �ȴ����߿���
    // ������ʼλ
    I2C_GenerateSTART(I2C1, ENABLE);
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_MODE_SELECT) && timeout--);
    if(timeout == 0) return 1;
    
    // �����豸��ַ(д)
    I2C_Send7bitAddress(I2C1, devAddr<<1, I2C_Direction_Transmitter);
    timeout = 10000;
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED) && timeout--);
    if(timeout == 0) return 1;
    
    // ���ͼĴ�����ַ
    I2C_SendData(I2C1, regAddr);
    timeout = 10000;
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_TRANSMITTED) && timeout--);
    if(timeout == 0) return 1;
    
    // ��������
    while(len--) {
        I2C_SendData(I2C1, *data++);
        timeout = 10000;
        while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_TRANSMITTED) && timeout--);
        if(timeout == 0) return 1;
    }
    
    // ����ֹͣλ
    I2C_GenerateSTOP(I2C1, ENABLE);
    return 0;
}

uint8_t I2C_ReadMulti(uint8_t devAddr, uint8_t regAddr, uint8_t *data, uint16_t len) {
    uint32_t timeout = 10000;
    
    while (I2C_GetFlagStatus(I2C1, I2C_FLAG_BUSY))
    ; // �ȴ����߿���
    // ������ʼλ
    I2C_GenerateSTART(I2C1, ENABLE);
    timeout = 10000;
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_MODE_SELECT) && timeout--);
    if(timeout == 0) return 1/*LED_DisplayBinary(1)*/;
    
    // �����豸��ַ(д)
    I2C_Send7bitAddress(I2C1, devAddr<<1, I2C_Direction_Transmitter);
    timeout = 10000;
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED) && timeout--);
    if(timeout == 0) return 1/*LED_DisplayBinary(2)*/;
    
    // ���ͼĴ�����ַ
    I2C_SendData(I2C1, regAddr);
    timeout = 10000;
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_TRANSMITTED) && timeout--);
    if(timeout == 0) return 1/*LED_DisplayBinary(3)*/;
    
    // ����������ʼλ
    I2C_GenerateSTART(I2C1, ENABLE);
    timeout = 10000;
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_MODE_SELECT) && timeout--);
    if(timeout == 0) return 1/*LED_DisplayBinary(4)*/;
    
    // �����豸��ַ(��)
    I2C_Send7bitAddress(I2C1, devAddr<<1, I2C_Direction_Receiver);
    
    if(len == 1) {
        // ����1�ֽ�����
        I2C_AcknowledgeConfig(I2C1, DISABLE);
        timeout = 10000;
        while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED) && timeout--);
        if(timeout == 0) return 1;
        
        // ����ֹͣλ
        I2C_GenerateSTOP(I2C1, ENABLE);
        
        // ��ȡ����
        timeout = 10000;
        while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_RECEIVED) && timeout--);
        if(timeout == 0) return 1;
        *data = I2C_ReceiveData(I2C1);
    } else {
        // ���ն��ֽ�����
        timeout = 10000;
        while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED) && timeout--);
        if(timeout == 0) return 1;
        
        // ����ǰn-1���ֽ�
        while(len > 2) {
            timeout = 10000;
            while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_RECEIVED) && timeout--);
            if(timeout == 0) return 1;
            *data++ = I2C_ReceiveData(I2C1);
            len--;
        }
        
        // ׼���������һ���ֽ�
        I2C_AcknowledgeConfig(I2C1, DISABLE);
        
        // ���յ����ڶ����ֽ�
        timeout = 10000;
        while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_RECEIVED) && timeout--);
        if(timeout == 0) return 1;
        *data++ = I2C_ReceiveData(I2C1);
        
        // ����ֹͣλ
        I2C_GenerateSTOP(I2C1, ENABLE);
        
        // �������һ���ֽ�
        timeout = 10000;
        while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_RECEIVED) && timeout--);
        if(timeout == 0) return 1;
        *data = I2C_ReceiveData(I2C1);
    }
    
    // ����ʹ��Ӧ��
    I2C_AcknowledgeConfig(I2C1, ENABLE);
    return 0;
}    