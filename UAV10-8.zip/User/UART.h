void UART1_Init(void);
void UART1_SendByte(uint8_t byte);
void UART1_SendString(char *str);