#pragma once
#include <stdint.h>
#include <stdbool.h>
#include "Restart.h"
#define SBUS_FRAME_SIZE 25
extern uint8_t sbus_buffer[SBUS_FRAME_SIZE];
extern uint16_t sbus_channels[16]; // �洢16��ͨ������
void SBUS_UART_Init(void);
void Parse_SBUS(void);
uint16_t SBUS_GetChannel(uint8_t channel);