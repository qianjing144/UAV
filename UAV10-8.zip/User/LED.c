#include "LED.h"

void LED_Init (void) {
    GPIO_InitTypeDef GPIO_InitStruct;

    RCC_APB2PeriphClockCmd (RCC_APB2Periph_GPIOB, ENABLE);

    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_LED1 | GPIO_PIN_LED2 | GPIO_PIN_LED3 | GPIO_PIN_LED4;  // ѡ��PB7����
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;                                      // �������
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;                                     // ����ٶ�50MHz

    GPIO_Init (GPIOB, &GPIO_InitStruct);

    GPIO_ResetBits (GPIOB, GPIO_Pin_LED1 | GPIO_PIN_LED2 | GPIO_PIN_LED3 | GPIO_PIN_LED4);
    // GPIO_SetBits (GPIOB, GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15);

}

void LED_On (LED_e LEDx) {
    switch (LEDx) {
    case LED1:
        GPIO_SetBits (GPIOB, GPIO_Pin_LED1);
        break;
    case LED2:
        GPIO_SetBits (GPIOB, GPIO_PIN_LED2);
        break;
    case LED3:
        GPIO_SetBits (GPIOB, GPIO_PIN_LED3);
        break;
    case LED4:
        GPIO_SetBits (GPIOB, GPIO_PIN_LED4);
        break;
    default:
        return;
    }
}

void LED_Off (LED_e LEDx) {
    switch (LEDx) {
    case LED1:
        GPIO_ResetBits (GPIOB, GPIO_Pin_LED1);
        break;
    case LED2:
        GPIO_ResetBits (GPIOB, GPIO_PIN_LED2);
        break;
    case LED3:
        GPIO_ResetBits (GPIOB, GPIO_PIN_LED3);
        break;
    case LED4:
        GPIO_ResetBits (GPIOB, GPIO_PIN_LED4);
        break;
    default:
        return;
    }
}

void LED_Toggle (LED_e LEDx) {
    switch (LEDx) {
    case LED1:
        GPIO_ResetBits (GPIOB, GPIO_Pin_LED1);
        if(GPIO_ReadOutputDataBit(GPIOB, GPIO_Pin_LED1)==Bit_SET) {
            GPIO_ResetBits(GPIOB, GPIO_Pin_LED1);
        }else {
            GPIO_SetBits(GPIOB, GPIO_Pin_LED1);
        }
        break;
    case LED2:
        GPIO_ResetBits (GPIOB, GPIO_PIN_LED2);
        if(GPIO_ReadOutputDataBit(GPIOB, GPIO_PIN_LED2)==Bit_SET) {
            GPIO_ResetBits(GPIOB, GPIO_PIN_LED2);
        }else {
            GPIO_SetBits(GPIOB, GPIO_PIN_LED2);
        }
        break;
    case LED3:
        GPIO_ResetBits (GPIOB, GPIO_PIN_LED3);
        if(GPIO_ReadOutputDataBit(GPIOB, GPIO_PIN_LED3)==Bit_SET) {
            GPIO_ResetBits(GPIOB, GPIO_PIN_LED3);
        }else {
            GPIO_SetBits(GPIOB, GPIO_PIN_LED3);
        }
        break;
    case LED4:
        GPIO_ResetBits (GPIOB, GPIO_PIN_LED4);
        if(GPIO_ReadOutputDataBit(GPIOB, GPIO_PIN_LED4)==Bit_SET) {
            GPIO_ResetBits(GPIOB, GPIO_PIN_LED4);
        }else {
            GPIO_SetBits(GPIOB, GPIO_PIN_LED4);
        }
        break;
    default:
        return;
    }
}
void LED_DisplayBinary(uint8_t num) {
    if(num > 15) {  // ���������
        LED_Off(LED1);
        LED_Off(LED2);
        LED_Off(LED3);
        LED_Off(LED4);
        return;
    }

    // ����������λ��LED1��Ӧbit3��LED2��Ӧbit2��LED3��Ӧbit1��LED4��Ӧbit0��
    uint8_t bit3 = (num >> 3) & 0x01; // LED1����λ
    uint8_t bit2 = (num >> 2) & 0x01; // LED2����λ
    uint8_t bit1 = (num >> 1) & 0x01; // LED3����λ
    uint8_t bit0 = num & 0x01;        // LED4����λ

    // ���ݱ����������LED״̬
    (bit3) ? LED_On(LED1) : LED_Off(LED1);
    (bit2) ? LED_On(LED2) : LED_Off(LED2);
    (bit1) ? LED_On(LED3) : LED_Off(LED3);
    (bit0) ? LED_On(LED4) : LED_Off(LED4);
}
