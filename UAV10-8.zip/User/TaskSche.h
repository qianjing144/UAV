#pragma once
#include "ch32v20x_tim.h"
#include "ch32v20x_rcc.h"
#include "Stabilizer.h"

//1ms
#define MAX_TASKS 10      // ���������
#define _TIM_PSC 720-1     // 1kHz
#define _TIM_ARR 200-1

void TaskSche_Init(void);
uint8_t TaskSche_AddTask(void (*task)(void), uint32_t delay, uint32_t period);
void TaskSche_Run(void);
