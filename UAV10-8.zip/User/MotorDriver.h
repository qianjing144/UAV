#pragma once
void MotorDriver_Init(void);
void MotorDriver_SetDuty(uint8_t channel, uint16_t duty);