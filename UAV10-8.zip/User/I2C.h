#pragma once
#include "ch32v20x.h"
#include "ch32v20x_gpio.h"
#include "ch32v20x_i2c.h"
#include "ch32v20x_rcc.h"

#define I2C_SPEED 100000  // 100kHz��׼ģʽ

void I2C_Init_All(void);
uint8_t I2C_WriteMulti(uint8_t devAddr, uint8_t regAddr, uint8_t *data, uint16_t len);
uint8_t I2C_ReadMulti(uint8_t devAddr, uint8_t regAddr, uint8_t *data, uint16_t len);